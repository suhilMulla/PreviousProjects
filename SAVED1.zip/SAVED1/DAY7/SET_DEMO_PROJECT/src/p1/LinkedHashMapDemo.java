package p1;
import java.util.*;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> newmap= new TreeMap();
		
		newmap.put(134, "R");
		newmap.put(111, "B");
		newmap.put(247, "Bh");
		newmap.put(109, "MAh");
		newmap.put(79, "sri");
		//newmap.put(null, "vi");
		//newmap.put(null, "g");
		        
		System.out.println(newmap);
	}

}
