package p1;
import java.util.*;

public class TreeMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
Map<Integer,String> lastmap= new TreeMap();
		
		lastmap.put(134, "R");
		lastmap.put(111, "B");
		lastmap.put(247, "Bh");
		lastmap.put(109, "MAh");
		lastmap.put(79, "sri");
		//lastmap.put(null, "vi");
		//newmap.put(null, "g");
		
		System.out.println(lastmap);
		
		
		

	}

}
