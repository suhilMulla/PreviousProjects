package p1;

public class HashMyMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
	//	Map<Integer> 
		
	
		
		
		
		
		
		//Set<interger> allkeys=mymap.keySet();
		
		
		
		

	}

}
