package p1;


import java.util.*;


public class HashSetDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		Set ourset=new HashSet();
		
		
		System.out.println(ourset.isEmpty());
		
		System.out.println(ourset.size());
		
		ourset.add(9999);
		
		ourset.add(8888);
		ourset.add(777);
		
		ourset.add(66);
		
		System.out.println(ourset.contains("ajay"));
		
		System.out.println(ourset);
		
		
		
		
		
		

	}

}
