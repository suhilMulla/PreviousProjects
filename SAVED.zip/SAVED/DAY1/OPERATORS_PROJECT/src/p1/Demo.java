package p1;

public class Demo {

	public static void main(String[] args) {
		int val=20;
		System.out.println(val>10);
		int val1=20;
		System.out.println(val==val1);
		
		int val2=21;
		
		System.out.println(val1!=val2);
		System.out.println(val1==val2);
		System.out.println(val2<=val2);
		
		
		System.out.println("------------------------");
		
		
		int a=100,b=50;
		//int res=0;
		//res=(a%b);
		
		System.out.println("mod=" + a%b);
		System.out.println("sub=" + (a-b));
		System.out.println("mul=" + a*b);
		System.out.println("div=" + a/b);
		
		
		
	}

}

	