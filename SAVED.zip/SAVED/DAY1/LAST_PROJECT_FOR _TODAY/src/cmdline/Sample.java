 package cmdline;

public class Sample {

	public static void main(String[] args) {
		
		for(int i=0;i<3;i++)
		{
			//System.out.print(args[i]+"");
		
		System.out.println("three musketeers are "+args[0]+ " "+ args[1]  +" "+ args[2]);
	}
	}

}


/*	
public static void main(String[] args) {
	
	for(String myval: args)
	{
		System.out.print(myval+"");
		
		
	}

}

*/
