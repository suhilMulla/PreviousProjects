package economypack;

public class SwitchDemo {

	public static void main(String[] args) {
		
		
		String loc="Bang1";
		//
		
		switch(loc)
		{
		
		case "Bang1" : System.out.println("richmond circle");
			break;
			
		case "Bang2" : System.out.println("st marks road office");
		break;
		
		case "Bang3" : System.out.println("electronic city");
		break;
		
		default: System.out.println("you are in wrong city. please recheck");
		
		}
		
		
		
		
		
		
		
	}

}
