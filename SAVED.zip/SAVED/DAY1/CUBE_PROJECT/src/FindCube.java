
public class FindCube {
	
	
	
	static int mycube(int val)
	{
		return (val*val*val)
				
	}

	//public static void main(String[] args) {
		
		//int temp
		
		
		
		
	}

}
