package pack1;

public class OddNumbers {

	public static void main(String[] args) {

		System.out.println("The Odd Numbers are:");
		
		for (int i = 1; i <= 30; i+=2) {
			System.out.print(i + "\t");
			
			
			//if (i % 2 != 0) {
			//System.out.print(i + "\t");}


	}

	}
}
