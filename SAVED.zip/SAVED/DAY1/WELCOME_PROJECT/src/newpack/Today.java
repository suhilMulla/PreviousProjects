package newpack;

import java.util.Date;

public class Today {

	public static void main(String[] args) {
		Date ref=new Date();
		
		System.out.println("current time and date is "+ ref.toString());
		

	}

}
