package p2;

abstract public class Vehicle {
	
	
	
	abstract	public void start();
	
	
	abstract	public void stop();

	public static void main(String[] args) {
		
		
		
		

	}

}
