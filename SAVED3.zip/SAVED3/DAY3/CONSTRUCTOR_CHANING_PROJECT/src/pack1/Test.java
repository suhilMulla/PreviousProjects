package pack1;

class Employee
{
	Employee()
	{
		super();
		System.out.println("Inside Employee constructor.....");
	}
}

class Manager extends Employee
{
	Manager()
	{
		super();
		System.out.println("inside manager constructor......");
	}
}

class Vice_President extends Manager
{
	Vice_President()
	{
		super();
		System.out.println("onside vice_presi");
	}
}

class CEO extends Vice_President
{
	CEO()
	{
		super();
		System.out.println("onside ceo const");
	}
}

public class Test {

	public static void main(String[] args) {
		
CEO myceo=new CEO();
	}

}
