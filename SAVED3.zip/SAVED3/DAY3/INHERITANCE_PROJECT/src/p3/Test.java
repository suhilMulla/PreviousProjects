package p3;

import p2.Derived;
import p1.Base;

public class Test {

	public static void main(String[] args) {
		
		Derived dref=new Derived();
		
		dref.setK(30);
		dref.showK();
		
	}

}
