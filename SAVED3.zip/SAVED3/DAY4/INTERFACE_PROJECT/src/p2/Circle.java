package p2;

 class Circle implements Shape {

	
	
	public  double area()
	{
		
		return(3.14*Shape.DIMENSION*Shape.DIMENSION);
	}
	public  double perimeter()
	{
		
		return(3.14*Shape.DIMENSION *2);
	}
	
	
	
}
