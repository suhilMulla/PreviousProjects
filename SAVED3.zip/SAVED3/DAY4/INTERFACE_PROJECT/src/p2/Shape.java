package p2;

public interface Shape {
	
	
	//abstract methods
	
	public abstract double area();
	public abstract double perimeter();
	
	//constant variables

	public static final int DIMENSION=4;
	
}
