package p2;

public class Test {

	public static void main(String[] args) {
		
		
		Circle s= new Circle();
		
		//Shape s;
		//s=new Circle();
		
		System.out.println("area"+s.area());
		
		System.out.println("perimeter"+s.perimeter());
		
	}

}
