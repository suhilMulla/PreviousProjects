package pp4;

import pp2.Derived;
import pp3.OurImpl;

public class Test {

	public static void main(String[] args) {
		
		Derived ref;
		
		ref =new OurImpl();
		
		ref.fun1();
		
		ref.fun2();
		
		
		//System.out.println(Derived.LOCATION);
		System.out.println(Derived.COMPNAME);
	}

}
