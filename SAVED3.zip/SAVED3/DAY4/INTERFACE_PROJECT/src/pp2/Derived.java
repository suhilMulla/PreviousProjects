package pp2;

import pp1.Base;

public interface Derived extends Base{
	
	
//public abstract void fun1();
	
	//public static final String COMPNAME="SLK";
	
	
	
	public abstract void fun2();
	public static final String LOCATION="BANGLORE";

}
