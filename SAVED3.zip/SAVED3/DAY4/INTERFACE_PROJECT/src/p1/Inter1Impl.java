package p1;

import java.util.Date;

class Inter1Impl implements Inter1{
	
public abstract void m1()
{
	System.out.println(""+ newDate());
}
	
	//public abstract void m2()
	///{
		
		
		
	//}
	
	
	
	
	

}
