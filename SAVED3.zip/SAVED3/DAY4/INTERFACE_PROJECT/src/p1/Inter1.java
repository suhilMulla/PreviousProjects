package p1;

public interface Inter1 {

	//public method
	
	public abstract void m1();
	
	//public abstract void m2();
	
	
	//public staic final variables
	
	public static final int CLASS_STRENGTH=17;
	
	
	
	
}
