package pp1;

public interface Base {

	
	public abstract void fun1();
	
	public static final String COMPNAME="SLK";
	
}
