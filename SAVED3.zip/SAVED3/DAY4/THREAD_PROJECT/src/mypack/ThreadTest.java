package mypack;

public class ThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
