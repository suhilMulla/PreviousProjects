package com.slksoft.web.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

import com.slksoft.entity.Product;
import com.slksoft.service.ProductsService;

//@WebServlet("/DescProductServlet")
public class DescProductServlet extends HttpServlet {
private static final long serialVersionUID = 1L;


protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


int id=Integer.parseInt(request.getParameter("id"));

ProductsService service= new ProductsService();

Product p=service.describeProduct(id);


request.setAttribute("brands", service.getAllBrands());
request.setAttribute("categories", service.getAllCategories());
request.setAttribute("product", service.describeProduct(id));


request.getRequestDispatcher("/WEB-INF/views/desc.jsp").forward(request,response);
}

}
